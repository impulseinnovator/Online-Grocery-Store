ONLINE GROCERY SHOPPING APPLICATION
- Flask for application code
- Jinja2 and Bootstrap for generation of HTML and CSS for styling
- SQlite for database

Step 1 - Extract the downloaded zip file.
Step 2 - Locate the requirements.txt file and install the required dependencies using the terminal or command prompt.
Step 3 - Open the extracted project folder in your preferred IDE. 
Step 4 - Find and run the main.py file to start the project execution.
Step 5 - Once the file execution is completed, check the terminal or command prompt for the server link. Use this link to access and run the web app.


Requirements
pip install flask
pip install Flask-SQLAlchemy
pip install flask-login

In case any No Module found error is seen,
execute 'pip install <module name>' in terminal

Run the main app
python main.py


Working of Application
There are mainly two categories present in the application.

I - Admin

Use an email with domain as '@admin' while registering as admin 
Add new categories in the database mentioning the details like name, description etc.
Add products in the respective categories providing the necessary details like name, rate per unit, manufacture/expiry date etc.


II - Normal User

Use any email id and password for creating an account as user
Select products from any category and add them to the cart
Place order from the cart