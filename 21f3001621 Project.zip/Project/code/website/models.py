from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func

class RegisteredUser(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    name = db.Column(db.String(100))
    is_admin = db.Column(db.Boolean)
    category = db.relationship('Category')
    order = db.relationship('Order')
    cart = db.relationship("Cart")
    product = db.relationship('Product', backref='RegisteredUser')

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    image = db.Column(db.String(255))
    manufacture_date = db.Column(db.DateTime(timezone=True))
    expiry_date = db.Column(db.DateTime(timezone=True))
    rate_per_unit = db.Column(db.Float, nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    product_admin_id = db.Column(db.Integer, db.ForeignKey('registered_user.id'))
    order = db.relationship('Order', backref='product', lazy=True)
    cart = db.relationship('Cart', backref='product', lazy=True)

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    image = db.Column(db.String(255))
    name = db.Column(db.String(100))
    category_admin_id = db.Column(db.Integer, db.ForeignKey('registered_user.id'))
    product = db.relationship('Product', backref='category', lazy=True)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('registered_user.id'))
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    total_units = db.Column(db.Integer)
    total_cost = db.Column(db.Float)
    order_date = db.Column(db.DateTime(timezone=True), default=func.now())
    address = db.Column(db.String(500))
    total = db.Column(db.Float)
    order_items = db.relationship('OrderItem', backref='order', lazy=True)
class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('registered_user.id'))
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    units = db.Column(db.Integer, nullable=False)
    rate_per_unit = db.Column(db.Float, nullable=False)
    total_cost = db.Column(db.Float)
    product_name = db.Column(db.String(100), nullable=False)

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer)

