from flask import render_template, request, Blueprint, redirect, url_for, flash, current_app, session
from .models import Category, Product, Cart, Order, OrderItem
from flask_login import current_user, login_required
from . import db
import secrets
import os
from datetime import datetime
from flask import g


view = Blueprint('views', __name__)


@view.route('/')
def home():
    category = Category.query.all()
    product = Product.query.all()

    return render_template('home.html', user=current_user, category=category)


from flask import request, render_template
from sqlalchemy import or_
from sqlalchemy import text
@view.route("/search", methods=['POST'])
def search():
    try:
        searched = request.form.get("searching")
        query = request.form.get("options")

        if query == 'Product Name':
            products = Product.query.filter(Product.name.contains(searched)).all()
            return render_template('home.html', user=current_user, category=products)

        elif query == 'Category Name':
            categories = Category.query.filter(Category.name.contains(searched)).all()
            return render_template('home.html', user=current_user, category=categories)



        else:
            return render_template('home.html', user=current_user, category=[])

    except Exception as e:
        categories = Category.query.all()
        return render_template('home.html', user=current_user, category=categories)

@view.route('/search1/<int:id>', methods=['GET', 'POST'])
def search1(id):
    try:
        category = Category.query.get(id)
        searched_product = request.form.get("searching_product")
        products_in_category = Product.query.filter_by(category_id=id).all()

        product_names_in_category = [product.name for product in products_in_category]
        products = []

        # Searching for products in the category by name
        for index in range(len(product_names_in_category)):
            if searched_product.lower() in product_names_in_category[index].lower():
                products.append(products_in_category[index])

        return render_template('select_products.html', category=category, user=current_user, products=products)

    except Exception as e:
        # log your exception
        category = Category.query.get(id)
        products_in_category = Product.query.filter_by(category_id=id).all()
        return render_template('select_products.html', category=category, user=current_user,
                               products=products_in_category)

@view.route('/categories')
@login_required
def categories():
    if current_user.is_admin:
        return render_template('categories.html', user=current_user)
    return redirect(url_for('views.home'))


@view.route('/add_category', methods=['GET', 'POST'])
@login_required
def add_categories():
    if current_user.is_admin:
        if request.method == 'POST':
            name_c = request.form.get('category_name')
            image_c = save_category_images(request.files['image'])

            if name_c is not None:
                new_category = Category(name=name_c, image=image_c, category_admin_id=current_user.id)
                db.session.add(new_category)
                db.session.commit()
                return redirect(url_for('views.categories'))

            if len(name_c.strip()) < 1:  # strip() is used to remove leading/trailing whitespace
                flash('Please fill the name field', category='error')
                return render_template('add_categories.html', user=current_user)

        else:
            return render_template('add_categories.html', user=current_user)
    return redirect(url_for('views.home'))


@view.route('/update_categories/<int:id>', methods=['POST', 'GET'])
@login_required
def update_categories(id):
    if current_user.is_admin:
        update_c = Category.query.get(id)
        if request.method == 'POST':
            update_c.image = save_category_images(request.files['image'])
            update_c.name = request.form.get('name')
            db.session.commit()
            return redirect(url_for('views.categories'))
        else:
            if update_c:
                return render_template('update_categories.html', user=current_user, category=update_c)
    else:
        return redirect(url_for('categories.home'))

@view.route('/delete_categories/<int:id>', methods=['POST', 'GET'])
@login_required
def delete_categories(id):
    if current_user.is_admin:
        products = Product.query.filter_by(category_id=id).all()
        print(products)
        delete_c = Category.query.get(id)
        print(delete_c)
        print(delete_c, " is deleted")
        db.session.delete(delete_c)
        for product in products:
            db.session.delete(product)
        print(id)
        db.session.commit()

        return redirect(url_for('views.categories'))

    else:
        print(2)
        return redirect(url_for('categories.home'))

@view.route('/products')
@login_required
def products():
    if current_user.is_admin:
        return render_template('my_products.html', user=current_user)
    return redirect(url_for('views.home'))

@view.route('/my_products', methods=['GET'])
@login_required
def my_products():
    if current_user.is_admin:
        my_products = Product.query.filter_by(product_admin_id=current_user.id).all()
        for product in my_products:
            print(product.name)
    return render_template('my_products.html', products=my_products, user=current_user)


@view.route('/select_products/<int:id>')
def select_products(id):


    product = Product.query.filter_by(category_id=int(id)).all()
    print(product)
    category = Category.query.get(int(id))
    print(category)

    if product:

        return render_template('select_products.html', user=current_user, products=product, category= category)
    else:
        flash('There are no products in this category', category='note')
        return redirect(url_for('views.home'))

@view.route('/add_products/<int:category_id>', methods=['GET', 'POST'])
@login_required
def add_product(category_id):
    if current_user.is_admin:
        if request.method == 'POST':
            product_name = request.form.get('name')
            manufacture_date = datetime.strptime(request.form.get('manufacture_date'), '%Y-%m-%d')
            expiry_date = datetime.strptime(request.form.get('expiry_date'), '%Y-%m-%d')
            rate_per_unit = request.form.get('rate')
            # category_id = request.form.get('category_id')  # You don't need this line anymore
            if len(product_name) >= 1:
                new_product = Product(name=product_name, manufacture_date=manufacture_date, expiry_date=expiry_date, rate_per_unit=rate_per_unit, category_id=category_id, product_admin_id=current_user.id)
                db.session.add(new_product)
                db.session.commit()
                print('Product added')
                flash('Your product is added', category='success')
                return redirect(url_for('views.my_products'))
            else:
                flash('Fill all the fields', category='error')
                return render_template('add_products.html', user=current_user)
        else:
            return render_template('add_products.html', user=current_user, category_id=category_id)
    return redirect(url_for('views.home'))

@view.route('/update_products/<int:id>', methods=['POST', 'GET'])
@login_required
def update_products(id):
    if current_user.is_admin:
        update_products = Product.query.get(int(id))
        if request.method == 'POST':
            update_products.name = request.form.get('name')
            update_products.manufacture_date = request.form.get('manufacture_date')
            update_products.expiry_date = request.form.get('expiry_date')
            update_products.rate_per_unit = request.form.get('rate')

            # Here we'll commit any changes made to the product to the database
            db.session.commit()
            return redirect(url_for('views.my_products'))

        else:  # Method is 'GET'
            if update_products:
                return render_template('update_products.html', user=current_user, product=update_products)

    else:
        return redirect(url_for('views.home'))  # If user is not admin, redirect to home

@view.route('/delete_products/<int:id>', methods=['POST', 'GET'])
@login_required
def delete_product(id):
    print('started')
    if current_user.is_admin:
        order = Order.query.filter_by(product_id=int(id)).all()
        print(order)
        product = Product.query.get(int(id))
        print(product)
        db.session.delete(product)
        for i in range(len(order)):
            db.session.delete(order[i])
        db.session.commit()

        return redirect(url_for('views.my_products'))

    else:
        print(2)
        return redirect(url_for('views.home'))



@view.route('/checkout/<int:id>', methods=['GET', 'POST'])
@login_required
def checkout(id):
    if current_user.is_admin == False:
        cart = Cart.query.get(int(id))

        if request.method == 'POST':
            p = Product.query.filter_by(name=str(cart.product_name)).first()
            quantity = request.form.get('quantity')
            p.available_quantity = int(p.available_quantity) - int(quantity)
            new_order = Order(ordered_product=cart.id, ordered_category=cart.category_id, user=current_user.id,
                              product=cart.product_name, total_quantity=quantity,
                              total_cost=int(p.rate_per_unit) * int(quantity))

            db.session.add(new_order)
            db.session.commit()

            return redirect(url_for('views.my_orders'))
        else:
            return render_template('checkout.html', user=current_user, cart=cart)
    else:
        return redirect(url_for('views.select_products'))

@view.route('show_orders/<int:id>')
@login_required
def show_orders(id):
    if current_user.is_admin:
        ords = Order.query.filter_by(ordered_product=int(id)).all()
        product = Product.query.get(int(id))
        return render_template('show_orders.html', user=current_user, orders=ords, product=product, order_count=len(ords))
    else:
        categories = Category.query.all()
        return render_template('home.html', user=current_user, categories=categories)

def save_category_images(image):
    hash_photo = secrets.token_urlsafe(10)
    _, file_extension = os.path.splitext(image.filename)
    image_name = hash_photo + file_extension
    # note change in directory to 'category_images'
    file_path = os.path.join(current_app.root_path, 'static/category_images', image_name)
    image.save(file_path)
    return image_name

def save_product_images(image):
    hash_photo = secrets.token_urlsafe(10)
    _, file_extension = os.path.splitext(image.filename)
    image_name = hash_photo + file_extension
    # note change in directory to 'product_images'
    file_path = os.path.join(current_app.root_path, 'static/product_images', image_name)
    image.save(file_path)
    return image_name

from flask import request, redirect, url_for, flash

@view.before_request
def before_request():
    if current_user.is_authenticated:
        g.total_cart_items = Cart.query.filter_by(user_id=current_user.id).count()
    else:
        g.total_cart_items = 0

@view.route('/add_to_cart', methods=['POST'])
@login_required
def add_to_cart():
    product_id = request.form.get('product_id')
    units = request.form.get('units')
    if units is None:
        flash('Units is not provided.', 'error')
        return redirect(url_for('views.cart'))

    try:
        units = int(units)
    except ValueError:
        flash('Units value must be a number.', 'error')
        return redirect(url_for('views.cart'))

    product = Product.query.get(product_id)
    if product is None:
        flash('Product not found.', 'error')
        return redirect(url_for('views.home'))

    cart_item = Cart.query.filter_by(user_id=current_user.id, product_id=product_id).first()
    if cart_item:

        cart_item.units += int(units)
    else:

        cart_item = Cart(
            user_id=current_user.id,
            product_id=product_id,
            category_id=product.category_id,
            units=units,
            rate_per_unit=product.rate_per_unit,
            total_cost=product.rate_per_unit * int(units),
            product_name=product.name
        )
        db.session.add(cart_item)

    db.session.commit()
    g.total_cart_items = Cart.query.filter_by(user_id=current_user.id).count()
    flash('Product added to cart.', 'success')
    return redirect(request.referrer or url_for('views.home'))


@view.route('/cart')
@login_required
def cart():
    cart_items = Cart.query.filter_by(user_id=current_user.id).all()
    total = sum(item.rate_per_unit * item.units for item in cart_items)
    return render_template('cart.html', items=cart_items, total=total, user=current_user)



#@your_blueprint.route('/place_order', methods=['POST'])   # uncomment this line if you are using blueprints
@view.route('/place_order', methods=['POST'])
@login_required
def place_order():
    Cart.query.filter_by(user_id=current_user.id).delete()
    db.session.commit()
    flash('Order placed successfully!', 'success')
    return redirect(url_for('views.home'))
